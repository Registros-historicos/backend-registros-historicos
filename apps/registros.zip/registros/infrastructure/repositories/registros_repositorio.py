from apps.registros.infrastructure.repositories.pg_utils import run_query
from apps.registros.domain.entities import Registro

class PostgresRegistroRepository:
    def get_by_expediente(self, no_expediente: str):
        query = "SELECT * FROM registro WHERE no_expediente = %s;"
        return run_query(query, [no_expediente], fetchone=True)

    def vincular_investigador(self, id_registro: int, curp: str):
        query = """
            INSERT INTO registro_investigador (id_registro, curp)
            VALUES (%s, %s)
            ON CONFLICT DO NOTHING;
        """
        run_query(query, [id_registro, curp])

    def crear_registro(self, registro: Registro):
        query = """
            INSERT INTO registro (
                no_expediente, titulo, descripcion, fec_solicitud,
                no_titulo, estatus_param, rama_param, medio_ingreso_param,
                tecnologico_origen, anio_renovacion, id_subsector,
                fec_expedicion, archivo, observaciones,
                tipo_registro_param, tipo_ingreso_param, id_usuario
            ) VALUES (
                %(no_expediente)s, %(titulo)s, %(descripcion)s, %(fec_solicitud)s,
                %(no_titulo)s, %(estatus_param)s, %(rama_param)s, %(medio_ingreso_param)s,
                %(tecnologico_origen)s, %(anio_renovacion)s, %(id_subsector)s,
                %(fec_expedicion)s, %(archivo)s, %(observaciones)s,
                %(tipo_registro_param)s, %(tipo_ingreso_param)s, %(id_usuario)s
            )
            ON CONFLICT (no_expediente)
            DO UPDATE SET
                titulo = EXCLUDED.titulo,
                descripcion = EXCLUDED.descripcion,
                estatus_param = EXCLUDED.estatus_param,
                rama_param = EXCLUDED.rama_param,
                medio_ingreso_param = EXCLUDED.medio_ingreso_param,
                tecnologico_origen = EXCLUDED.tecnologico_origen,
                anio_renovacion = EXCLUDED.anio_renovacion,
                id_subsector = EXCLUDED.id_subsector,
                fec_expedicion = EXCLUDED.fec_expedicion,
                archivo = EXCLUDED.archivo,
                observaciones = EXCLUDED.observaciones,
                tipo_registro_param = EXCLUDED.tipo_registro_param,
                tipo_ingreso_param = EXCLUDED.tipo_ingreso_param,
                id_usuario = EXCLUDED.id_usuario
            RETURNING *;
        """
        return run_query(query, vars(registro), fetchone=True)
