from apps.registros.infrastructure.repositories.pg_utils import run_query

class PostgresInvestigadorRepository:
    def upsert_investigador(self, curp: str, data: dict):
        query = """
            INSERT INTO investigador (curp, nombres, apellido_paterno, apellido_materno, sexo,
                                      tipo_investigador, institucion, programa_educativo,
                                      cuerpo_academico, departamento, fecha_afiliacion,
                                      fecha_fin, observaciones)
            VALUES (%(curp)s, %(nombres)s, %(apellido_paterno)s, %(apellido_materno)s, %(sexo)s,
                    %(tipo_investigador)s, %(institucion)s, %(programa_educativo)s,
                    %(cuerpo_academico)s, %(departamento)s, %(fecha_afiliacion)s,
                    %(fecha_fin)s, %(observaciones)s)
            ON CONFLICT (curp) DO UPDATE
            SET nombres = EXCLUDED.nombres,
                apellido_paterno = EXCLUDED.apellido_paterno,
                apellido_materno = EXCLUDED.apellido_materno,
                sexo = EXCLUDED.sexo,
                tipo_investigador = EXCLUDED.tipo_investigador,
                institucion = EXCLUDED.institucion,
                programa_educativo = EXCLUDED.programa_educativo,
                cuerpo_academico = EXCLUDED.cuerpo_academico,
                departamento = EXCLUDED.departamento,
                fecha_afiliacion = EXCLUDED.fecha_afiliacion,
                fecha_fin = EXCLUDED.fecha_fin,
                observaciones = EXCLUDED.observaciones
            RETURNING *;
        """
        return run_query(query, data, fetchone=True)
