from apps.registros.infrastructure.repositories.registros_repositorio import PostgresRegistroRepository
from apps.registros.infrastructure.repositories.investigadores_repositorio import PostgresInvestigadorRepository

repo_registro = PostgresRegistroRepository()
repo_investigador = PostgresInvestigadorRepository()

def add_investigador_to_registro(curp: str, investigador_data: dict, no_expediente: str):
    investigador = repo_investigador.upsert_investigador(curp, investigador_data)
    registro = repo_registro.get_by_expediente(no_expediente)
    if registro and investigador:
        repo_registro.vincular_investigador(registro["id_registro"], investigador["curp"])
